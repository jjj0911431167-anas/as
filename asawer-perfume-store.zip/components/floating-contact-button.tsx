import { View, TouchableOpacity, Text, Linking, Animated } from "react-native";
import { useEffect, useRef, useState } from "react";
import { useColors } from "@/hooks/use-colors";

const CONTACT_METHODS = [
  {
    id: "whatsapp",
    icon: "💬",
    label: "واتس",
    color: "#25D366",
    url: "https://wa.me/0916596999",
  },
  {
    id: "phone",
    icon: "☎️",
    label: "اتصال",
    color: "#0084ff",
    url: "tel:0916596999",
  },
  {
    id: "email",
    icon: "📧",
    label: "بريد",
    color: "#EA4335",
    url: "mailto:joncarl0093@gmail.com",
  },
];

export function FloatingContactButton() {
  const colors = useColors();
  const [isOpen, setIsOpen] = useState(false);
  const scaleAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(scaleAnim, {
      toValue: isOpen ? 1 : 0,
      useNativeDriver: true,
    }).start();
  }, [isOpen]);

  const handleContact = (url: string) => {
    Linking.openURL(url);
  };

  return (
    <View className="absolute bottom-6 right-6 gap-4">
      {/* Contact Options */}
      <Animated.View
        style={{
          transform: [{ scale: scaleAnim }],
          opacity: scaleAnim,
        }}
        className="gap-3"
      >
        {CONTACT_METHODS.map((method) => (
          <TouchableOpacity
            key={method.id}
            onPress={() => handleContact(method.url)}
            className="flex-row items-center gap-2"
          >
            <View
              className="rounded-full p-3 items-center justify-center"
              style={{ backgroundColor: method.color }}
            >
              <Text className="text-xl">{method.icon}</Text>
            </View>
            <View className="bg-black/80 rounded-lg px-3 py-2">
              <Text className="text-white font-semibold text-sm">{method.label}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </Animated.View>

      {/* Main Button */}
      <TouchableOpacity
        onPress={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full items-center justify-center"
        style={{ backgroundColor: colors.primary }}
      >
        <Text className="text-2xl">{isOpen ? "✕" : "💬"}</Text>
      </TouchableOpacity>
    </View>
  );
}
