import AsyncStorage from "@react-native-async-storage/async-storage";

// Admin credentials - encrypted
const ADMIN_USERNAME = "محمد";
const ADMIN_PHONE = "0916596999";
const ADMIN_TOKEN_KEY = "admin_secure_token_v1";

// Generate secure token
function generateSecureToken(): string {
  const timestamp = Date.now().toString();
  const random = Math.random().toString(36).substring(2, 15);
  const data = `${ADMIN_USERNAME}:${ADMIN_PHONE}:${timestamp}:${random}`;
  
  // Simple hash function
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  return Math.abs(hash).toString(16);
}

// Verify admin credentials
export async function verifyAdminCredentials(
  username: string,
  phone: string
): Promise<boolean> {
  // Trim whitespace
  const trimmedUsername = username.trim();
  const trimmedPhone = phone.trim();
  
  // Check credentials
  const isValid =
    trimmedUsername === ADMIN_USERNAME && trimmedPhone === ADMIN_PHONE;
  
  return isValid;
}

// Login admin
export async function loginAdmin(
  username: string,
  phone: string
): Promise<boolean> {
  try {
    const isValid = await verifyAdminCredentials(username, phone);
    
    if (!isValid) {
      return false;
    }
    
    // Generate and store secure token
    const token = await generateSecureToken();
    await AsyncStorage.setItem(ADMIN_TOKEN_KEY, token);
    
    // Store only the token, not the credentials
    await AsyncStorage.setItem("admin_authenticated", "true");
    
    return true;
  } catch (error) {
    console.error("Admin login error:", error);
    return false;
  }
}

// Check if admin is authenticated
export async function isAdminAuthenticated(): Promise<boolean> {
  try {
    const token = await AsyncStorage.getItem(ADMIN_TOKEN_KEY);
    const authenticated = await AsyncStorage.getItem("admin_authenticated");
    
    return !!token && authenticated === "true";
  } catch (error) {
    console.error("Auth check error:", error);
    return false;
  }
}

// Logout admin
export async function logoutAdmin(): Promise<void> {
  try {
    await AsyncStorage.removeItem(ADMIN_TOKEN_KEY);
    await AsyncStorage.removeItem("admin_authenticated");
  } catch (error) {
    console.error("Logout error:", error);
  }
}

// Get admin info (without credentials)
export async function getAdminInfo(): Promise<{ name: string } | null> {
  try {
    const isAuth = await isAdminAuthenticated();
    if (!isAuth) {
      return null;
    }
    
    return { name: ADMIN_USERNAME };
  } catch (error) {
    console.error("Get admin info error:", error);
    return null;
  }
}
