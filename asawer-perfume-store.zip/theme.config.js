/** @type {const} */
const themeColors = {
  primary: { light: '#D4AF37', dark: '#D4AF37' },
  background: { light: '#ffffff', dark: '#1a1a1a' },
  surface: { light: '#f9f9f9', dark: '#2a2a2a' },
  foreground: { light: '#1a1a1a', dark: '#f5f5f5' },
  muted: { light: '#666666', dark: '#999999' },
  border: { light: '#e0e0e0', dark: '#333333' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
