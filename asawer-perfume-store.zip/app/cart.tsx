import { ScrollView, Text, View, TouchableOpacity, FlatList, TextInput } from "react-native";
import { useEffect, useState } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function CartScreen() {
  const colors = useColors();
  const [cart, setCart] = useState<any[]>([]);
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const validateCouponMutation = trpc.coupons.validate.useMutation();
  const createOrderMutation = trpc.orders.create.useMutation();

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    try {
      const cartData = await AsyncStorage.getItem("cart");
      setCart(cartData ? JSON.parse(cartData) : []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const removeFromCart = async (productId: number) => {
    const updatedCart = cart.filter((item) => item.productId !== productId);
    setCart(updatedCart);
    await AsyncStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  const updateQuantity = async (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId);
      return;
    }
    const updatedCart = cart.map((item) =>
      item.productId === productId ? { ...item, quantity: newQuantity } : item
    );
    setCart(updatedCart);
    await AsyncStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  const calculateTotal = () => {
    return cart.reduce((sum, item) => sum + parseFloat(item.price) * item.quantity, 0);
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) {
      alert("أدخل كود الكوبون");
      return;
    }

    try {
      const result = await validateCouponMutation.mutateAsync({
        code: couponCode,
        totalPrice: calculateTotal(),
      });

      if (result.valid) {
        setAppliedCoupon(result.coupon);
        alert("تم تطبيق الكوبون بنجاح!");
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert("حدث خطأ في التحقق من الكوبون");
    }
  };

  const handleCheckout = async () => {
    try {
      const customer = await AsyncStorage.getItem("customer");
      if (!customer) {
        alert("يرجى تسجيل الدخول أولاً");
        return;
      }

      const customerData = JSON.parse(customer);
      const total = calculateTotal();
      const discount = appliedCoupon ? appliedCoupon.discountValue : 0;

      const orderNumber = `ORD-${Date.now()}`;

      await createOrderMutation.mutateAsync({
        orderNumber,
        customerName: customerData.name,
        customerPhone: customerData.phone,
        customerAddress: "سيتم تحديده لاحقاً",
        totalPrice: total.toString(),
        discountAmount: discount.toString(),
        couponCode: appliedCoupon?.code,
        items: cart,
      });

      // Clear cart
      await AsyncStorage.removeItem("cart");
      setCart([]);

      alert("تم استقبال طلبك بنجاح! سيتم التواصل معك قريباً.");
      router.replace("/(tabs)/");
    } catch (error) {
      console.error(error);
      alert("حدث خطأ أثناء إنشاء الطلب");
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">جاري التحميل...</Text>
      </ScreenContainer>
    );
  }

  if (cart.length === 0) {
    return (
      <ScreenContainer containerClassName="bg-background" className="items-center justify-center">
        <View className="gap-4 items-center">
          <Text className="text-4xl">🛒</Text>
          <Text className="text-xl font-bold text-foreground">السلة فارغة</Text>
          <Text className="text-sm text-muted text-center">أضف منتجات لبدء التسوق</Text>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/")}
            className="bg-primary rounded-lg px-6 py-3 mt-4"
          >
            <Text className="text-background font-bold">العودة للتسوق</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const total = calculateTotal();
  const discount = appliedCoupon
    ? appliedCoupon.discountType === "percentage"
      ? (total * parseFloat(appliedCoupon.discountValue)) / 100
      : parseFloat(appliedCoupon.discountValue)
    : 0;
  const finalTotal = total - discount;

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-2xl text-background">←</Text>
          </TouchableOpacity>
          <Text className="text-lg font-bold text-background">سلة المشتريات</Text>
          <View className="w-6" />
        </View>

        {/* Cart Items */}
        <View className="px-4 py-6">
          <FlatList
            data={cart}
            scrollEnabled={false}
            keyExtractor={(item) => item.productId.toString()}
            renderItem={({ item }) => (
              <View className="bg-surface border border-border rounded-lg p-4 mb-3">
                <View className="flex-row items-start justify-between mb-3">
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold">{item.productName}</Text>
                    <Text className="text-primary font-bold mt-1">{item.price} ريال</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => removeFromCart(item.productId)}
                    className="bg-error/20 rounded-lg p-2"
                  >
                    <Text className="text-error font-bold">✕</Text>
                  </TouchableOpacity>
                </View>

                {/* Quantity Controls */}
                <View className="flex-row items-center gap-3 bg-background rounded-lg p-2">
                  <TouchableOpacity
                    onPress={() => updateQuantity(item.productId, item.quantity - 1)}
                    className="w-8 h-8 items-center justify-center bg-primary/20 rounded"
                  >
                    <Text className="text-primary font-bold">−</Text>
                  </TouchableOpacity>
                  <Text className="flex-1 text-center text-foreground font-semibold">{item.quantity}</Text>
                  <TouchableOpacity
                    onPress={() => updateQuantity(item.productId, item.quantity + 1)}
                    className="w-8 h-8 items-center justify-center bg-primary/20 rounded"
                  >
                    <Text className="text-primary font-bold">+</Text>
                  </TouchableOpacity>
                </View>

                {/* Subtotal */}
                <View className="mt-3 pt-3 border-t border-border">
                  <Text className="text-sm text-muted">
                    الإجمالي: {(parseFloat(item.price) * item.quantity).toFixed(2)} ريال
                  </Text>
                </View>
              </View>
            )}
          />
        </View>

        {/* Coupon Section */}
        <View className="px-4 gap-3">
          <Text className="text-sm font-semibold text-foreground">كود الخصم</Text>
          <View className="flex-row gap-2">
            <TextInput
              placeholder="أدخل كود الكوبون"
              value={couponCode}
              onChangeText={setCouponCode}
              editable={!appliedCoupon}
              className="flex-1 bg-surface border border-border rounded-lg p-3 text-foreground"
              style={{ color: colors.foreground, borderColor: colors.border }}
            />
            <TouchableOpacity
              onPress={appliedCoupon ? () => setAppliedCoupon(null) : handleApplyCoupon}
              disabled={validateCouponMutation.isPending}
              className={`px-4 rounded-lg items-center justify-center ${
                appliedCoupon ? "bg-error" : "bg-primary"
              }`}
            >
              <Text className="text-background font-semibold text-xs">
                {appliedCoupon ? "إلغاء" : "تطبيق"}
              </Text>
            </TouchableOpacity>
          </View>
          {appliedCoupon && (
            <View className="bg-success/10 border border-success rounded-lg p-3">
              <Text className="text-success font-semibold text-sm">✓ تم تطبيق الكوبون: {appliedCoupon.code}</Text>
            </View>
          )}
        </View>

        {/* Summary */}
        <View className="px-4 py-6 gap-3 border-t border-border mt-6">
          <View className="flex-row items-center justify-between">
            <Text className="text-foreground">المجموع الفرعي:</Text>
            <Text className="text-foreground font-semibold">{total.toFixed(2)} ريال</Text>
          </View>
          {discount > 0 && (
            <View className="flex-row items-center justify-between">
              <Text className="text-success">الخصم:</Text>
              <Text className="text-success font-bold">-{discount.toFixed(2)} ريال</Text>
            </View>
          )}
          <View className="flex-row items-center justify-between pt-3 border-t border-border">
            <Text className="text-lg font-bold text-foreground">الإجمالي:</Text>
            <Text className="text-2xl font-bold text-primary">{finalTotal.toFixed(2)} ريال</Text>
          </View>
        </View>

        {/* Checkout Button */}
        <View className="px-4 pb-6 gap-3">
          <TouchableOpacity
            onPress={handleCheckout}
            disabled={createOrderMutation.isPending}
            className="bg-primary rounded-lg p-4 items-center"
          >
            <Text className="text-background font-bold text-lg">
              {createOrderMutation.isPending ? "جاري المعالجة..." : "إتمام الطلب"}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/")}
            className="border border-primary rounded-lg p-4 items-center"
          >
            <Text className="text-primary font-semibold">متابعة التسوق</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
