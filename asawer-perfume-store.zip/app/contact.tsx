import { ScrollView, Text, View, TouchableOpacity, Linking } from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const CONTACT_INFO = {
  phone: "0916596999",
  email: "joncarl0093@gmail.com",
  whatsapp: "0916596999",
  instagram: "https://instagram.com",
  tiktok: "https://tiktok.com",
  telegram: "https://t.me",
  address: "راس لانوف: خلف مصرف التجاري بجوار حديقه الالعاب",
};

export default function ContactScreen() {
  const colors = useColors();

  const handleCall = () => {
    Linking.openURL(`tel:${CONTACT_INFO.phone}`);
  };

  const handleWhatsApp = () => {
    Linking.openURL(`https://wa.me/${CONTACT_INFO.whatsapp}`);
  };

  const handleEmail = () => {
    Linking.openURL(`mailto:${CONTACT_INFO.email}`);
  };

  const handleInstagram = () => {
    Linking.openURL(CONTACT_INFO.instagram);
  };

  const handleTikTok = () => {
    Linking.openURL(CONTACT_INFO.tiktok);
  };

  const handleTelegram = () => {
    Linking.openURL(CONTACT_INFO.telegram);
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-2xl text-background">←</Text>
          </TouchableOpacity>
          <Text className="text-lg font-bold text-background">تواصل معنا</Text>
          <View className="w-6" />
        </View>

        {/* Contact Info */}
        <View className="px-4 py-6 gap-6">
          {/* Store Info */}
          <View className="bg-surface border border-border rounded-lg p-6 gap-4">
            <Text className="text-xl font-bold text-foreground">محل أساور للعطور</Text>
            <View className="gap-3">
              <View className="gap-1">
                <Text className="text-xs text-muted">العنوان</Text>
                <Text className="text-foreground font-semibold">{CONTACT_INFO.address}</Text>
              </View>
              <View className="gap-1">
                <Text className="text-xs text-muted">رقم الهاتف</Text>
                <Text className="text-foreground font-semibold">{CONTACT_INFO.phone}</Text>
              </View>
              <View className="gap-1">
                <Text className="text-xs text-muted">البريد الإلكتروني</Text>
                <Text className="text-foreground font-semibold">{CONTACT_INFO.email}</Text>
              </View>
            </View>
          </View>

          {/* Quick Contact */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">تواصل سريع</Text>

            {/* WhatsApp */}
            <TouchableOpacity
              onPress={handleWhatsApp}
              className="bg-success rounded-lg p-4 flex-row items-center justify-between"
            >
              <Text className="text-background font-semibold">واتس آب</Text>
              <Text className="text-2xl">💬</Text>
            </TouchableOpacity>

            {/* Phone Call */}
            <TouchableOpacity
              onPress={handleCall}
              className="bg-primary rounded-lg p-4 flex-row items-center justify-between"
            >
              <Text className="text-background font-semibold">اتصال مباشر</Text>
              <Text className="text-2xl">☎️</Text>
            </TouchableOpacity>

            {/* Email */}
            <TouchableOpacity
              onPress={handleEmail}
              className="bg-foreground/10 border border-foreground/20 rounded-lg p-4 flex-row items-center justify-between"
            >
              <Text className="text-foreground font-semibold">البريد الإلكتروني</Text>
              <Text className="text-2xl">📧</Text>
            </TouchableOpacity>
          </View>

          {/* Social Media */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">وسائل التواصل الاجتماعي</Text>

            <View className="flex-row gap-3">
              {/* Instagram */}
              <TouchableOpacity
                onPress={handleInstagram}
                className="flex-1 bg-pink-500 rounded-lg p-4 items-center gap-2"
              >
                <Text className="text-2xl">📷</Text>
                <Text className="text-white font-semibold text-xs">Instagram</Text>
              </TouchableOpacity>

              {/* TikTok */}
              <TouchableOpacity
                onPress={handleTikTok}
                className="flex-1 bg-black rounded-lg p-4 items-center gap-2"
              >
                <Text className="text-2xl">🎵</Text>
                <Text className="text-white font-semibold text-xs">TikTok</Text>
              </TouchableOpacity>

              {/* Telegram */}
              <TouchableOpacity
                onPress={handleTelegram}
                className="flex-1 bg-blue-500 rounded-lg p-4 items-center gap-2"
              >
                <Text className="text-2xl">✈️</Text>
                <Text className="text-white font-semibold text-xs">Telegram</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Message */}
          <View className="bg-primary/10 border border-primary/20 rounded-lg p-4 gap-2">
            <Text className="text-sm font-semibold text-foreground">ساعات العمل</Text>
            <Text className="text-sm text-muted">من الساعة 10 صباحاً إلى 10 مساءً</Text>
            <Text className="text-sm text-muted">جميع أيام الأسبوع</Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
