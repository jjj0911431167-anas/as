import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useEffect, useState } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function AdminDashboardScreen() {
  const colors = useColors();
  const [admin, setAdmin] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Fetch data
  const { data: stats } = trpc.stats.orders.useQuery();
  const { data: productStats } = trpc.stats.products.useQuery();
  const { data: orders } = trpc.orders.list.useQuery();
  const [newOrdersCount, setNewOrdersCount] = useState(0);

  useEffect(() => {
    // Count new orders (pending status)
    if (orders) {
      const pending = orders.filter((o: any) => o.status === "pending").length;
      setNewOrdersCount(pending);
    }
  }, [orders]);

  // Auto-refresh orders every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      // Trigger refetch
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    checkAdminLogin();
  }, []);

  const checkAdminLogin = async () => {
    try {
      const adminData = await AsyncStorage.getItem("admin");
      if (!adminData) {
        router.replace("/admin-login");
      } else {
        setAdmin(JSON.parse(adminData));
      }
    } catch (error) {
      console.error(error);
      router.replace("/admin-login");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem("admin");
      router.replace("/admin-login");
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">جاري التحميل...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <View className="gap-2 flex-1">
            <View className="flex-row items-center gap-2">
              <Text className="text-3xl font-bold text-background">⚙️ لوحة الإدارة</Text>
              {newOrdersCount > 0 && (
                <View className="bg-error rounded-full w-6 h-6 items-center justify-center">
                  <Text className="text-white font-bold text-xs">{newOrdersCount}</Text>
                </View>
              )}
            </View>
            <Text className="text-sm text-background/80">مرحباً {admin?.name}</Text>
          </View>
          <TouchableOpacity
            onPress={handleLogout}
            className="bg-background/20 rounded-lg p-3"
          >
            <Text className="text-background font-semibold">خروج</Text>
          </TouchableOpacity>
        </View>

        {/* Statistics */}
        <View className="px-4 gap-3 mt-6">
          <Text className="text-xl font-bold text-foreground">الإحصائيات</Text>
          
          {/* Stats Cards */}
          <View className="gap-3">
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-muted mb-1">إجمالي الطلبات</Text>
              <Text className="text-3xl font-bold text-primary">{stats?.totalOrders || 0}</Text>
            </View>
            
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-muted mb-1">إجمالي الإيرادات</Text>
              <Text className="text-3xl font-bold text-primary">{stats?.totalRevenue || 0} ريال</Text>
            </View>
            
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-muted mb-1">الطلبات المعلقة</Text>
              <Text className="text-3xl font-bold text-warning">{stats?.pendingOrders || 0}</Text>
            </View>
            
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-muted mb-1">إجمالي المنتجات</Text>
              <Text className="text-3xl font-bold text-primary">{productStats?.totalProducts || 0}</Text>
            </View>
          </View>
        </View>

        {/* Management Options */}
        <View className="px-4 gap-3 mt-6">
          <Text className="text-xl font-bold text-foreground">الإدارة</Text>
          
          <TouchableOpacity
            onPress={() => router.push("/admin/products")}
            className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
          >
            <View>
              <Text className="text-foreground font-semibold">إدارة المنتجات</Text>
              <Text className="text-xs text-muted mt-1">إضافة وتعديل وحذف المنتجات</Text>
            </View>
            <Text className="text-2xl">📦</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/admin/categories")}
            className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
          >
            <View>
              <Text className="text-foreground font-semibold">إدارة الأقسام</Text>
              <Text className="text-xs text-muted mt-1">إضافة وتعديل الأقسام</Text>
            </View>
            <Text className="text-2xl">📂</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/admin/coupons")}
            className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
          >
            <View>
              <Text className="text-foreground font-semibold">إدارة الكوبونات</Text>
              <Text className="text-xs text-muted mt-1">إنشاء وتعديل الخصومات</Text>
            </View>
            <Text className="text-2xl">🎟️</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/admin/orders")}
            className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
          >
            <View>
              <Text className="text-foreground font-semibold">إدارة الطلبات</Text>
              <Text className="text-xs text-muted mt-1">عرض وتحديث الطلبات</Text>
            </View>
            <Text className="text-2xl">📋</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Orders */}
        {orders && orders.length > 0 && (
          <View className="px-4 gap-3 mt-6 mb-6">
            <Text className="text-xl font-bold text-foreground">آخر الطلبات</Text>
            
            <FlatList
              data={orders.slice(0, 5)}
              scrollEnabled={false}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View className="bg-surface border border-border rounded-lg p-4 mb-3">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-foreground font-semibold">#{item.orderNumber}</Text>
                    <View
                      className={`px-3 py-1 rounded-full ${
                        item.status === "pending"
                          ? "bg-warning/20"
                          : item.status === "delivered"
                          ? "bg-success/20"
                          : "bg-primary/20"
                      }`}
                    >
                      <Text
                        className={`text-xs font-semibold ${
                          item.status === "pending"
                            ? "text-warning"
                            : item.status === "delivered"
                            ? "text-success"
                            : "text-primary"
                        }`}
                      >
                        {item.status}
                      </Text>
                    </View>
                  </View>
                  <Text className="text-sm text-muted mb-1">{item.customerName}</Text>
                  <Text className="text-primary font-bold">{item.totalPrice} ريال</Text>
                </View>
              )}
            />
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
