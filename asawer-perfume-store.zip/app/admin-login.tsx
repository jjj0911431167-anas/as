import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const ADMIN_NAME = "محمد";
const ADMIN_PASSWORD = "0916596999";

export default function AdminLoginScreen() {
  const colors = useColors();
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    if (!name.trim() || !password.trim()) {
      setError("يرجى إدخال الاسم وكلمة المرور");
      return;
    }

    if (name !== ADMIN_NAME || password !== ADMIN_PASSWORD) {
      setError("الاسم أو كلمة المرور غير صحيحة");
      return;
    }

    setLoading(true);
    setError("");

    try {
      // حفظ بيانات الإدارة
      await AsyncStorage.setItem(
        "admin",
        JSON.stringify({
          name: ADMIN_NAME,
          loginTime: new Date().toISOString(),
        })
      );

      // الانتقال إلى لوحة الإدارة
      router.replace("/admin-dashboard");
    } catch (err) {
      setError("حدث خطأ أثناء تسجيل الدخول");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 justify-center gap-8">
          {/* Header */}
          <View className="items-center gap-4">
            <Text className="text-4xl font-bold text-primary">⚙️ لوحة الإدارة</Text>
            <Text className="text-xl font-semibold text-foreground">أساور للعطور والهدايا</Text>
            <Text className="text-base text-muted text-center">تسجيل دخول المسؤول</Text>
          </View>

          {/* Error Message */}
          {error ? (
            <View className="bg-error/10 border border-error rounded-lg p-4">
              <Text className="text-error text-center font-medium">{error}</Text>
            </View>
          ) : null}

          {/* Form */}
          <View className="gap-4">
            {/* Name Input */}
            <View className="gap-2">
              <Text className="text-base font-semibold text-foreground">اسم المسؤول</Text>
              <TextInput
                placeholder="أدخل اسم المسؤول"
                placeholderTextColor={colors.muted}
                value={name}
                onChangeText={setName}
                editable={!loading}
                className="bg-surface border border-border rounded-lg p-4 text-foreground"
                style={{
                  color: colors.foreground,
                  borderColor: colors.border,
                }}
              />
            </View>

            {/* Password Input */}
            <View className="gap-2">
              <Text className="text-base font-semibold text-foreground">كلمة المرور</Text>
              <TextInput
                placeholder="أدخل كلمة المرور"
                placeholderTextColor={colors.muted}
                value={password}
                onChangeText={setPassword}
                editable={!loading}
                secureTextEntry
                className="bg-surface border border-border rounded-lg p-4 text-foreground"
                style={{
                  color: colors.foreground,
                  borderColor: colors.border,
                }}
              />
            </View>
          </View>

          {/* Login Button */}
          <TouchableOpacity
            onPress={handleLogin}
            disabled={loading}
            className="bg-primary rounded-lg p-4 items-center justify-center"
            style={{
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading ? (
              <ActivityIndicator color={colors.background} />
            ) : (
              <Text className="text-background font-bold text-lg">دخول</Text>
            )}
          </TouchableOpacity>

          {/* Back Button */}
          <TouchableOpacity
            onPress={() => router.back()}
            className="border border-primary rounded-lg p-4 items-center justify-center"
          >
            <Text className="text-primary font-semibold text-base">العودة</Text>
          </TouchableOpacity>

          {/* Info */}
          <View className="bg-surface border border-border rounded-lg p-4 gap-2">
            <Text className="text-sm font-semibold text-foreground">معلومات الدخول</Text>
            <Text className="text-xs text-muted leading-relaxed">
              اسم المسؤول: محمد{"\n"}
              كلمة المرور: 0916596999
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
