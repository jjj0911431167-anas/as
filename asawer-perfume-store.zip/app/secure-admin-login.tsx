import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { loginAdmin } from "@/lib/admin-auth";

export default function SecureAdminLoginScreen() {
  const colors = useColors();
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    if (!username.trim() || !phone.trim()) {
      Alert.alert("خطأ", "يرجى ملء جميع الحقول");
      return;
    }

    setLoading(true);
    try {
      const success = await loginAdmin(username, phone);
      if (success) {
        router.replace("/admin-dashboard");
      } else {
        Alert.alert("خطأ", "بيانات الدخول غير صحيحة");
        setPhone("");
      }
    } catch (error) {
      Alert.alert("خطأ", "حدث خطأ أثناء محاولة الدخول");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
        {/* Background gradient */}
        <View className="flex-1 bg-gradient-to-b from-primary/10 to-background items-center justify-center p-6">
          {/* Decorative circles */}
          <View
            className="absolute top-10 right-10 w-32 h-32 rounded-full opacity-5"
            style={{ backgroundColor: colors.primary }}
          />
          <View
            className="absolute bottom-20 left-5 w-40 h-40 rounded-full opacity-5"
            style={{ backgroundColor: colors.primary }}
          />

          {/* Login card */}
          <View className="w-full max-w-sm bg-surface rounded-3xl p-8 gap-6 shadow-lg border border-border">
            {/* Header */}
            <View className="items-center gap-3">
              <View className="w-20 h-20 bg-primary rounded-full items-center justify-center">
                <Text className="text-4xl">🔐</Text>
              </View>
              <Text className="text-2xl font-bold text-foreground">لوحة الإدارة</Text>
              <Text className="text-xs text-muted text-center">
                منطقة محمية - الدخول للمسؤولين فقط
              </Text>
            </View>

            {/* Form */}
            <View className="gap-4">
              {/* Username */}
              <View className="gap-2">
                <Text className="text-sm font-semibold text-foreground">اسم المستخدم</Text>
                <View className="flex-row items-center bg-background rounded-lg border border-border px-4 py-3">
                  <TextInput
                    placeholder="أدخل اسم المستخدم"
                    placeholderTextColor={colors.muted}
                    value={username}
                    onChangeText={setUsername}
                    editable={!loading}
                    className="flex-1 text-foreground"
                    style={{ fontFamily: "Tajawal" }}
                  />
                  <Text className="text-lg">👤</Text>
                </View>
              </View>

              {/* Phone */}
              <View className="gap-2">
                <Text className="text-sm font-semibold text-foreground">رقم الهاتف</Text>
                <View className="flex-row items-center bg-background rounded-lg border border-border px-4 py-3">
                  <TextInput
                    placeholder="أدخل رقم الهاتف"
                    placeholderTextColor={colors.muted}
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                    secureTextEntry={!showPassword}
                    editable={!loading}
                    className="flex-1 text-foreground"
                    style={{ fontFamily: "Tajawal" }}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                    <Text className="text-lg">{showPassword ? "👁️" : "🔒"}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            {/* Login button */}
            <TouchableOpacity
              onPress={handleLogin}
              disabled={loading}
              className="bg-primary rounded-lg p-4 items-center"
              style={{ opacity: loading ? 0.6 : 1 }}
            >
              <Text className="text-background font-bold text-lg">
                {loading ? "جاري الدخول..." : "دخول"}
              </Text>
            </TouchableOpacity>

            {/* Warning */}
            <View className="bg-warning/10 border border-warning/20 rounded-lg p-3">
              <Text className="text-xs text-warning text-center">
                ⚠️ هذه منطقة محمية. محاولات الدخول غير المصرح بها قد تسجل
              </Text>
            </View>
          </View>

          {/* Footer info */}
          <Text className="text-xs text-muted mt-8 text-center">
            تطبيق أساور للعطور والهدايا والإكسسوارات
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
