import { ScrollView, Text, View, TouchableOpacity, FlatList, Image } from "react-native";
import { useEffect, useState } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { FloatingContactButton } from "@/components/floating-contact-button";

export default function HomeScreen() {
  const colors = useColors();
  const [customer, setCustomer] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Fetch data
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: bestsellerProducts } = trpc.products.bestsellers.useQuery({ limit: 6 });
  const { data: onSaleProducts } = trpc.products.onSale.useQuery();

  useEffect(() => {
    checkCustomerLogin();
  }, []);

  const checkCustomerLogin = async () => {
    try {
      const customerData = await AsyncStorage.getItem("customer");
      if (!customerData) {
        router.replace("/customer-login");
      } else {
        setCustomer(JSON.parse(customerData));
      }
    } catch (error) {
      console.error(error);
      router.replace("/customer-login");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">جاري التحميل...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2">
          <Text className="text-3xl font-bold text-background">أساور</Text>
          <Text className="text-sm text-background/80">مرحباً {customer?.name}</Text>
        </View>

        {/* Welcome Banner */}
        <View className="bg-surface m-4 rounded-lg p-6 gap-3">
          <Text className="text-2xl font-bold text-foreground">مرحباً بك في متجرنا</Text>
          <Text className="text-sm text-muted">استكشف أفضل العطور والهدايا والإكسسوارات</Text>
          <TouchableOpacity className="bg-primary rounded-lg p-3 mt-2">
            <Text className="text-background font-semibold text-center">ابدأ التسوق</Text>
          </TouchableOpacity>
        </View>

        {/* Categories */}
        <View className="px-4 gap-3">
          <Text className="text-xl font-bold text-foreground">الأقسام</Text>
          <FlatList
            data={categories}
            horizontal
            scrollEnabled={false}
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                className="bg-surface rounded-lg p-4 mr-3 items-center justify-center flex-1"
                style={{ minWidth: 100 }}
              >
                <Text className="text-foreground font-semibold text-center text-sm">{item.name}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Best Sellers */}
        {bestsellerProducts && bestsellerProducts.length > 0 && (
          <View className="px-4 gap-3 mt-6">
            <Text className="text-xl font-bold text-foreground">الأكثر مبيعاً</Text>
            <FlatList
              data={bestsellerProducts}
              horizontal
              scrollEnabled={false}
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  className="bg-surface rounded-lg overflow-hidden mr-3"
                  style={{ width: 150 }}
                >
                  <View className="bg-primary/20 h-32 items-center justify-center">
                    <Text className="text-3xl">📦</Text>
                  </View>
                  <View className="p-3 gap-2">
                    <Text className="text-foreground font-semibold text-sm" numberOfLines={2}>
                      {item.name}
                    </Text>
                    <Text className="text-primary font-bold">{item.price} ريال</Text>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        )}

        {/* On Sale */}
        {onSaleProducts && onSaleProducts.length > 0 && (
          <View className="px-4 gap-3 mt-6 mb-6">
            <Text className="text-xl font-bold text-foreground">العروض الخاصة</Text>
            <FlatList
              data={onSaleProducts}
              horizontal
              scrollEnabled={false}
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  className="bg-error/10 border border-error rounded-lg p-3 mr-3"
                  style={{ width: 150 }}
                >
                  <Text className="text-error font-bold text-sm mb-2">🎉 عرض خاص</Text>
                  <Text className="text-foreground font-semibold text-sm" numberOfLines={2}>
                    {item.name}
                  </Text>
                  <View className="gap-1 mt-2">
                    {item.discountPrice && (
                      <Text className="text-primary font-bold">{item.discountPrice} ريال</Text>
                    )}
                    <Text className="text-muted line-through text-xs">{item.price} ريال</Text>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        )}

        {/* Admin Button */}
        <View className="px-4 pb-6">
          <TouchableOpacity
            onPress={() => router.push("/categories")}
            className="bg-primary rounded-lg p-4"
          >
            <Text className="text-background font-semibold text-center">🛍️ تصفح جميع المنتجات</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/cart")}
            className="bg-foreground/10 border border-foreground/20 rounded-lg p-4"
          >
            <Text className="text-foreground font-semibold text-center">🛒 السلة</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/contact")}
            className="bg-foreground/10 border border-foreground/20 rounded-lg p-4"
          >
            <Text className="text-foreground font-semibold text-center">📞 تواصل معنا</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => router.push("/admin-login")}
            className="bg-foreground/10 border border-foreground/20 rounded-lg p-4"
          >
            <Text className="text-foreground font-semibold text-center">⚙️ لوحة الإدارة</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      <FloatingContactButton />
    </ScreenContainer>
  );
}
