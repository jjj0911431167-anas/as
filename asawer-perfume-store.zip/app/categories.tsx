import { ScrollView, Text, View, TouchableOpacity, FlatList } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useState } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function CategoriesScreen() {
  const colors = useColors();
  const { categoryId } = useLocalSearchParams();
  const [selectedCategoryId, setSelectedCategoryId] = useState(categoryId ? parseInt(categoryId as string) : null);

  // Fetch data
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: products } = trpc.products.list.useQuery(
    { categoryId: selectedCategoryId || undefined },
    { enabled: true }
  );

  const selectedCategory = categories?.find((c) => c.id === selectedCategoryId);

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-2xl text-background">←</Text>
          </TouchableOpacity>
          <Text className="text-lg font-bold text-background">الأقسام</Text>
          <View className="w-6" />
        </View>

        {/* Categories Tabs */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          className="px-4 py-4"
          contentContainerStyle={{ gap: 8 }}
        >
          <TouchableOpacity
            onPress={() => setSelectedCategoryId(null)}
            className={`px-4 py-2 rounded-full ${
              selectedCategoryId === null
                ? "bg-primary"
                : "bg-surface border border-border"
            }`}
          >
            <Text
              className={`font-semibold ${
                selectedCategoryId === null
                  ? "text-background"
                  : "text-foreground"
              }`}
            >
              الكل
            </Text>
          </TouchableOpacity>

          {categories?.map((category) => (
            <TouchableOpacity
              key={category.id}
              onPress={() => setSelectedCategoryId(category.id)}
              className={`px-4 py-2 rounded-full ${
                selectedCategoryId === category.id
                  ? "bg-primary"
                  : "bg-surface border border-border"
              }`}
            >
              <Text
                className={`font-semibold ${
                  selectedCategoryId === category.id
                    ? "text-background"
                    : "text-foreground"
                }`}
              >
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Products Grid */}
        <View className="px-4 pb-6">
          {selectedCategory && (
            <Text className="text-lg font-bold text-foreground mb-4">
              {selectedCategory.name}
            </Text>
          )}

          <FlatList
            data={products}
            scrollEnabled={false}
            numColumns={2}
            columnWrapperStyle={{ gap: 12 }}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => router.push(`/product-detail?id=${item.id}`)}
                className="flex-1 bg-surface border border-border rounded-lg overflow-hidden"
              >
                {/* Image */}
                <View className="bg-primary/10 h-32 items-center justify-center">
                  <Text className="text-4xl">📦</Text>
                </View>

                {/* Info */}
                <View className="p-3 gap-2">
                  <Text className="text-foreground font-semibold text-sm" numberOfLines={2}>
                    {item.name}
                  </Text>

                  {/* Price */}
                  <View className="gap-1">
                    {item.discountPrice ? (
                      <>
                        <Text className="text-primary font-bold">{item.discountPrice} ريال</Text>
                        <Text className="text-muted line-through text-xs">{item.price} ريال</Text>
                      </>
                    ) : (
                      <Text className="text-primary font-bold">{item.price} ريال</Text>
                    )}
                  </View>

                  {/* Badge */}
                  {item.isOnSale && (
                    <View className="bg-error/20 rounded px-2 py-1 self-start">
                      <Text className="text-error text-xs font-bold">عرض خاص</Text>
                    </View>
                  )}

                  {/* Add to Cart Button */}
                  <TouchableOpacity
                    onPress={() => router.push(`/product-detail?id=${item.id}`)}
                    className="bg-primary rounded mt-2 py-2 items-center"
                  >
                    <Text className="text-background font-semibold text-xs">اختر</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            )}
            ListEmptyComponent={
              <View className="items-center justify-center py-12">
                <Text className="text-muted">لا توجد منتجات</Text>
              </View>
            }
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
