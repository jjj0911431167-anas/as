import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, Animated } from "react-native";
import { useState, useEffect, useRef } from "react";
import { router } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function CustomerLoginScreen() {
  const colors = useColors();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleLogin = async () => {
    if (!name.trim() || !phone.trim()) {
      setError("يرجى إدخال الاسم ورقم الهاتف");
      return;
    }

    setLoading(true);
    setError("");

    try {
      await AsyncStorage.setItem(
        "customer",
        JSON.stringify({
          name: name.trim(),
          phone: phone.trim(),
          loginTime: new Date().toISOString(),
        })
      );

      router.replace("/(tabs)/");
    } catch (err) {
      setError("حدث خطأ أثناء تسجيل الدخول");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <Animated.View style={{ opacity: fadeAnim }} className="flex-1 bg-gradient-to-b from-primary/5 to-background items-center justify-center p-6">
          {/* Decorative background */}
          <View className="absolute top-10 right-10 w-40 h-40 rounded-full opacity-5" style={{ backgroundColor: colors.primary }} />
          <View className="absolute bottom-20 left-5 w-48 h-48 rounded-full opacity-5" style={{ backgroundColor: colors.primary }} />

          <View className="w-full max-w-sm gap-8">
            {/* Header */}
            <View className="items-center gap-4">
              <View className="w-24 h-24 bg-primary rounded-full items-center justify-center shadow-lg">
                <Text className="text-5xl">✨</Text>
              </View>
              <View className="items-center gap-2">
                <Text className="text-3xl font-bold text-primary">أساور</Text>
                <Text className="text-sm text-muted">للعطور والهدايا والإكسسوارات</Text>
              </View>
            </View>

            {/* Error Message */}
            {error ? (
              <View className="bg-error/10 border border-error rounded-lg p-4">
                <Text className="text-error text-center font-medium">{error}</Text>
              </View>
            ) : null}

            {/* Form Card */}
            <View className="bg-surface rounded-3xl p-8 gap-6 shadow-lg border border-border">
              <View className="items-center gap-2">
                <Text className="text-lg font-bold text-foreground">مرحباً بك</Text>
                <Text className="text-xs text-muted">أدخل بيانات للدخول للمتجر</Text>
              </View>

              {/* Name Input */}
              <View className="gap-3">
                <Text className="text-sm font-semibold text-foreground">الاسم الكامل</Text>
                <View className="flex-row items-center bg-background rounded-xl border border-border px-4 py-3 gap-3">
                  <TextInput
                    placeholder="أدخل اسمك"
                    placeholderTextColor={colors.muted}
                    value={name}
                    onChangeText={setName}
                    editable={!loading}
                    className="flex-1 text-foreground text-base"
                    style={{ fontFamily: "Tajawal" }}
                  />
                  <Text className="text-xl">👤</Text>
                </View>
              </View>

              {/* Phone Input */}
              <View className="gap-3">
                <Text className="text-sm font-semibold text-foreground">رقم الهاتف</Text>
                <View className="flex-row items-center bg-background rounded-xl border border-border px-4 py-3 gap-3">
                  <TextInput
                    placeholder="أدخل رقم هاتفك"
                    placeholderTextColor={colors.muted}
                    value={phone}
                    onChangeText={setPhone}
                    keyboardType="phone-pad"
                    editable={!loading}
                    className="flex-1 text-foreground text-base"
                    style={{ fontFamily: "Tajawal" }}
                  />
                  <Text className="text-xl">📱</Text>
                </View>
              </View>

              {/* Login Button */}
              <TouchableOpacity
                onPress={handleLogin}
                disabled={loading}
                className="bg-primary rounded-xl p-4 items-center mt-2"
                style={{ opacity: loading ? 0.7 : 1 }}
              >
                {loading ? (
                  <ActivityIndicator color={colors.background} />
                ) : (
                  <Text className="text-background font-bold text-base">دخول</Text>
                )}
              </TouchableOpacity>

              {/* Info message */}
              <View className="bg-primary/10 border border-primary/20 rounded-lg p-3">
                <Text className="text-xs text-primary text-center">
                  ℹ️ لا تحتاج لكلمة مرور - فقط اسمك ورقم هاتفك
                </Text>
              </View>
            </View>

            {/* Features */}
            <View className="gap-3">
              <View className="flex-row gap-3 items-center">
                <Text className="text-2xl">🎁</Text>
                <Text className="text-sm text-muted flex-1">عطور أصلية وهدايا فاخرة</Text>
              </View>
              <View className="flex-row gap-3 items-center">
                <Text className="text-2xl">💎</Text>
                <Text className="text-sm text-muted flex-1">إكسسوارات وزينة راقية</Text>
              </View>
              <View className="flex-row gap-3 items-center">
                <Text className="text-2xl">🚚</Text>
                <Text className="text-sm text-muted flex-1">توصيل سريع وآمن</Text>
              </View>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </ScreenContainer>
  );
}
