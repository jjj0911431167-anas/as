import { ScrollView, Text, View, TouchableOpacity, Image, TextInput } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function ProductDetailScreen() {
  const colors = useColors();
  const { id } = useLocalSearchParams();
  const [quantity, setQuantity] = useState("1");
  const [addedToCart, setAddedToCart] = useState(false);

  // Fetch product
  const { data: product } = trpc.products.getById.useQuery(
    { id: parseInt(id as string) },
    { enabled: !!id }
  );

  const handleAddToCart = async () => {
    if (!product) return;

    try {
      const cartData = await AsyncStorage.getItem("cart");
      const cart = cartData ? JSON.parse(cartData) : [];

      const existingItem = cart.find((item: any) => item.productId === product.id);
      const qty = parseInt(quantity) || 1;

      if (existingItem) {
        existingItem.quantity += qty;
      } else {
        cart.push({
          productId: product.id,
          productName: product.name,
          price: product.discountPrice || product.price,
          quantity: qty,
          image: product.image,
        });
      }

      await AsyncStorage.setItem("cart", JSON.stringify(cart));
      setAddedToCart(true);
      setTimeout(() => setAddedToCart(false), 2000);
    } catch (error) {
      console.error(error);
    }
  };

  if (!product) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">جاري التحميل...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-4 flex-row items-center justify-between">
          <TouchableOpacity onPress={() => router.back()}>
            <Text className="text-2xl text-background">←</Text>
          </TouchableOpacity>
          <Text className="text-lg font-bold text-background flex-1 text-center">تفاصيل المنتج</Text>
          <View className="w-6" />
        </View>

        {/* Product Image */}
        <View className="bg-surface h-64 items-center justify-center">
          <Text className="text-6xl">📦</Text>
        </View>

        {/* Product Info */}
        <View className="px-4 py-6 gap-4">
          {/* Name and Price */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">{product.name}</Text>
            <View className="flex-row items-center gap-3">
              {product.discountPrice ? (
                <>
                  <Text className="text-2xl font-bold text-primary">{product.discountPrice} ريال</Text>
                  <Text className="text-lg text-muted line-through">{product.price} ريال</Text>
                </>
              ) : (
                <Text className="text-2xl font-bold text-primary">{product.price} ريال</Text>
              )}
            </View>
          </View>

          {/* Description */}
          {product.description && (
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">الوصف</Text>
              <Text className="text-sm text-muted leading-relaxed">{product.description}</Text>
            </View>
          )}

          {/* Availability */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">التوفر</Text>
            <Text className={`text-sm font-semibold ${product.quantity > 0 ? "text-success" : "text-error"}`}>
              {product.quantity > 0 ? `${product.quantity} قطعة متوفرة` : "غير متوفر حالياً"}
            </Text>
          </View>

          {/* Quantity Selector */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">الكمية</Text>
            <View className="flex-row items-center gap-3 bg-surface rounded-lg p-3">
              <TouchableOpacity
                onPress={() => setQuantity(Math.max(1, parseInt(quantity) - 1).toString())}
                className="w-10 h-10 items-center justify-center bg-primary/20 rounded-lg"
              >
                <Text className="text-primary font-bold">−</Text>
              </TouchableOpacity>
              <TextInput
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="number-pad"
                className="flex-1 text-center text-foreground font-bold"
              />
              <TouchableOpacity
                onPress={() => setQuantity((parseInt(quantity) + 1).toString())}
                className="w-10 h-10 items-center justify-center bg-primary/20 rounded-lg"
              >
                <Text className="text-primary font-bold">+</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Add to Cart Button */}
          <TouchableOpacity
            onPress={handleAddToCart}
            disabled={product.quantity <= 0}
            className="bg-primary rounded-lg p-4 items-center mt-4"
            style={{ opacity: product.quantity <= 0 ? 0.5 : 1 }}
          >
            <Text className="text-background font-bold text-lg">
              {addedToCart ? "✓ تمت الإضافة" : "أضف إلى السلة"}
            </Text>
          </TouchableOpacity>

          {/* Continue Shopping */}
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/")}
            className="border border-primary rounded-lg p-4 items-center"
          >
            <Text className="text-primary font-semibold">متابعة التسوق</Text>
          </TouchableOpacity>

          {/* Go to Cart */}
          <TouchableOpacity
            onPress={() => router.push("/cart")}
            className="bg-foreground/10 rounded-lg p-4 items-center"
          >
            <Text className="text-foreground font-semibold">عرض السلة</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
