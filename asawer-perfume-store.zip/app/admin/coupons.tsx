import { ScrollView, Text, View, TouchableOpacity, FlatList, TextInput, Modal, Switch } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function AdminCouponsScreen() {
  const colors = useColors();
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    code: "",
    description: "",
    discountType: "percentage" as const,
    discountValue: "",
    maxUses: "",
    isActive: true,
  });

  // Fetch data
  const { data: coupons, refetch: refetchCoupons } = trpc.coupons.list.useQuery();
  const createCouponMutation = trpc.coupons.create.useMutation({
    onSuccess: () => {
      refetchCoupons();
      setShowAddModal(false);
      setFormData({
        code: "",
        description: "",
        discountType: "percentage",
        discountValue: "",
        maxUses: "",
        isActive: true,
      });
    },
  });

  const handleAddCoupon = async () => {
    if (!formData.code || !formData.discountValue) {
      alert("يرجى إدخال الكود والخصم");
      return;
    }

    try {
      await createCouponMutation.mutateAsync({
        ...formData,
        maxUses: formData.maxUses ? parseInt(formData.maxUses) : undefined,
      });
    } catch (error) {
      console.error(error);
      alert("حدث خطأ أثناء إضافة الكوبون");
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <View className="gap-2 flex-1">
            <Text className="text-2xl font-bold text-background">🎟️ إدارة الكوبونات</Text>
          </View>
          <TouchableOpacity
            onPress={() => router.back()}
            className="bg-background/20 rounded-lg p-3"
          >
            <Text className="text-background font-semibold">رجوع</Text>
          </TouchableOpacity>
        </View>

        {/* Add Coupon Button */}
        <View className="px-4 mt-6 mb-6">
          <TouchableOpacity
            onPress={() => setShowAddModal(true)}
            className="bg-primary rounded-lg p-4 items-center"
          >
            <Text className="text-background font-bold text-lg">+ إضافة كوبون جديد</Text>
          </TouchableOpacity>
        </View>

        {/* Coupons List */}
        <View className="px-4 pb-6">
          <Text className="text-lg font-bold text-foreground mb-4">الكوبونات ({coupons?.length || 0})</Text>
          
          <FlatList
            data={coupons}
            scrollEnabled={false}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View className="bg-surface border border-border rounded-lg p-4 mb-3">
                <View className="flex-row items-start justify-between mb-2">
                  <View className="flex-1">
                    <Text className="text-foreground font-bold text-lg">{item.code}</Text>
                    {item.description && (
                      <Text className="text-xs text-muted mt-1">{item.description}</Text>
                    )}
                  </View>
                  <View className={`px-3 py-1 rounded-full ${item.isActive ? "bg-success/20" : "bg-error/20"}`}>
                    <Text className={`text-xs font-semibold ${item.isActive ? "text-success" : "text-error"}`}>
                      {item.isActive ? "فعال" : "معطل"}
                    </Text>
                  </View>
                </View>
                <View className="flex-row items-center justify-between mt-3 pt-3 border-t border-border gap-2">
                  <View>
                    <Text className="text-xs text-muted">الخصم</Text>
                    <Text className="text-primary font-bold">
                      {item.discountValue} {item.discountType === "percentage" ? "%" : "ريال"}
                    </Text>
                  </View>
                  <View>
                    <Text className="text-xs text-muted">الاستخدامات</Text>
                    <Text className="text-foreground font-semibold">
                      {item.currentUses || 0} / {item.maxUses || "∞"}
                    </Text>
                  </View>
                  <View className="flex-row gap-2 ml-auto">
                    <TouchableOpacity className="bg-primary/20 rounded-lg p-2">
                      <Text className="text-primary font-semibold text-xs">تعديل</Text>
                    </TouchableOpacity>
                    <TouchableOpacity className="bg-error/20 rounded-lg p-2">
                      <Text className="text-error font-semibold text-xs">حذف</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
            ListEmptyComponent={
              <View className="items-center justify-center py-8">
                <Text className="text-muted">لا توجد كوبونات حالياً</Text>
              </View>
            }
          />
        </View>
      </ScrollView>

      {/* Add Coupon Modal */}
      <Modal visible={showAddModal} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-3xl p-6 gap-4">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-2xl font-bold text-foreground">إضافة كوبون جديد</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <Text className="text-2xl text-foreground">✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} className="max-h-96">
              {/* Coupon Code */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">كود الكوبون</Text>
                <TextInput
                  placeholder="أدخل كود الكوبون"
                  value={formData.code}
                  onChangeText={(text) => setFormData({ ...formData, code: text.toUpperCase() })}
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Discount Type */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">نوع الخصم</Text>
                <View className="flex-row gap-3">
                  <TouchableOpacity
                    onPress={() => setFormData({ ...formData, discountType: "percentage" })}
                    className={`flex-1 rounded-lg p-3 items-center ${
                      formData.discountType === "percentage"
                        ? "bg-primary"
                        : "bg-surface border border-border"
                    }`}
                  >
                    <Text
                      className={`font-semibold ${
                        formData.discountType === "percentage"
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      نسبة مئوية %
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => setFormData({ ...formData, discountType: "fixed" })}
                    className={`flex-1 rounded-lg p-3 items-center ${
                      formData.discountType === "fixed"
                        ? "bg-primary"
                        : "bg-surface border border-border"
                    }`}
                  >
                    <Text
                      className={`font-semibold ${
                        formData.discountType === "fixed"
                          ? "text-background"
                          : "text-foreground"
                      }`}
                    >
                      مبلغ ثابت
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Discount Value */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">قيمة الخصم</Text>
                <TextInput
                  placeholder="أدخل قيمة الخصم"
                  value={formData.discountValue}
                  onChangeText={(text) => setFormData({ ...formData, discountValue: text })}
                  keyboardType="decimal-pad"
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Max Uses */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">عدد الاستخدامات (اختياري)</Text>
                <TextInput
                  placeholder="اترك فارغاً للاستخدام غير محدود"
                  value={formData.maxUses}
                  onChangeText={(text) => setFormData({ ...formData, maxUses: text })}
                  keyboardType="number-pad"
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Description */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">الوصف (اختياري)</Text>
                <TextInput
                  placeholder="أدخل وصف الكوبون"
                  value={formData.description}
                  onChangeText={(text) => setFormData({ ...formData, description: text })}
                  multiline
                  numberOfLines={3}
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Active */}
              <View className="gap-2 mb-6 flex-row items-center justify-between">
                <Text className="text-sm font-semibold text-foreground">تفعيل الكوبون</Text>
                <Switch
                  value={formData.isActive}
                  onValueChange={(value) => setFormData({ ...formData, isActive: value })}
                />
              </View>

              {/* Add Button */}
              <TouchableOpacity
                onPress={handleAddCoupon}
                disabled={createCouponMutation.isPending}
                className="bg-primary rounded-lg p-4 items-center"
              >
                <Text className="text-background font-bold text-lg">
                  {createCouponMutation.isPending ? "جاري الإضافة..." : "إضافة الكوبون"}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
