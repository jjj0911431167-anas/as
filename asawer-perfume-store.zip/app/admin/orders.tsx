import { ScrollView, Text, View, TouchableOpacity, FlatList, Modal, Linking } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function AdminOrdersScreen() {
  const colors = useColors();
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  // Fetch data
  const { data: orders, refetch: refetchOrders } = trpc.orders.list.useQuery();
  const updateOrderMutation = trpc.orders.update.useMutation({
    onSuccess: () => {
      refetchOrders();
    },
  });

  const handleStatusChange = async (orderId: number, newStatus: string) => {
    try {
      await updateOrderMutation.mutateAsync({
        id: orderId,
        status: newStatus as any,
      });
      
      // Send WhatsApp notification
      if (selectedOrder) {
        const message = `مرحباً ${selectedOrder.customerName}، تم تحديث حالة طلبك #${selectedOrder.orderNumber} إلى: ${getStatusLabel(newStatus)}`;
        const whatsappUrl = `https://wa.me/${selectedOrder.customerPhone}?text=${encodeURIComponent(message)}`;
        Linking.openURL(whatsappUrl);
      }
    } catch (error) {
      console.error(error);
      alert("حدث خطأ أثناء تحديث الطلب");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "warning";
      case "confirmed":
        return "primary";
      case "shipped":
        return "primary";
      case "delivered":
        return "success";
      case "cancelled":
        return "error";
      default:
        return "muted";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return "معلق";
      case "confirmed":
        return "مؤكد";
      case "shipped":
        return "مرسل";
      case "delivered":
        return "تم التسليم";
      case "cancelled":
        return "ملغى";
      default:
        return status;
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <View className="gap-2 flex-1">
            <Text className="text-2xl font-bold text-background">📋 إدارة الطلبات</Text>
          </View>
          <TouchableOpacity
            onPress={() => router.back()}
            className="bg-background/20 rounded-lg p-3"
          >
            <Text className="text-background font-semibold">رجوع</Text>
          </TouchableOpacity>
        </View>

        {/* Orders List */}
        <View className="px-4 py-6 pb-6">
          <Text className="text-lg font-bold text-foreground mb-4">الطلبات ({orders?.length || 0})</Text>
          
          <FlatList
            data={orders}
            scrollEnabled={false}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => {
                  setSelectedOrder(item);
                  setShowDetailsModal(true);
                }}
                className="bg-surface border border-border rounded-lg p-4 mb-3"
              >
                <View className="flex-row items-start justify-between mb-3">
                  <View className="flex-1">
                    <Text className="text-foreground font-bold text-lg">#{item.orderNumber}</Text>
                    <Text className="text-xs text-muted mt-1">{item.customerName}</Text>
                    {item.status === "pending" && (
                      <View className="bg-error/20 rounded px-2 py-1 mt-2 self-start">
                        <Text className="text-error text-xs font-bold">🔴 جديد</Text>
                      </View>
                    )}
                  </View>
                  <View
                    className={`px-3 py-1 rounded-full bg-${getStatusColor(item.status)}/20`}
                  >
                    <Text
                      className={`text-xs font-semibold text-${getStatusColor(item.status)}`}
                    >
                      {getStatusLabel(item.status)}
                    </Text>
                  </View>
                </View>

                <View className="flex-row items-center justify-between pt-3 border-t border-border">
                  <View>
                    <Text className="text-xs text-muted">المبلغ</Text>
                    <Text className="text-primary font-bold">{item.totalPrice} ريال</Text>
                  </View>
                  <View>
                    <Text className="text-xs text-muted">التاريخ</Text>
                    <Text className="text-foreground font-semibold text-sm">
                      {new Date(item.createdAt).toLocaleDateString("ar-SA")}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            )}
            ListEmptyComponent={
              <View className="items-center justify-center py-8">
                <Text className="text-muted">لا توجد طلبات حالياً</Text>
              </View>
            }
          />
        </View>
      </ScrollView>

      {/* Order Details Modal */}
      <Modal visible={showDetailsModal} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-3xl p-6 gap-4 max-h-96">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-2xl font-bold text-foreground">تفاصيل الطلب</Text>
              <TouchableOpacity onPress={() => setShowDetailsModal(false)}>
                <Text className="text-2xl text-foreground">✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {selectedOrder && (
                <View className="gap-4">
                  {/* Order Info */}
                  <View className="bg-surface border border-border rounded-lg p-4 gap-3">
                    <View>
                      <Text className="text-xs text-muted mb-1">رقم الطلب</Text>
                      <Text className="text-foreground font-bold">#{selectedOrder.orderNumber}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-muted mb-1">العميل</Text>
                      <Text className="text-foreground font-semibold">{selectedOrder.customerName}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-muted mb-1">الهاتف</Text>
                      <Text className="text-foreground">{selectedOrder.customerPhone}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-muted mb-1">العنوان</Text>
                      <Text className="text-foreground">{selectedOrder.customerAddress}</Text>
                    </View>
                  </View>

                  {/* Amount */}
                  <View className="bg-primary/10 border border-primary/20 rounded-lg p-4 gap-2">
                    <View className="flex-row items-center justify-between">
                      <Text className="text-foreground">المبلغ الإجمالي:</Text>
                      <Text className="text-primary font-bold text-lg">{selectedOrder.totalPrice} ريال</Text>
                    </View>
                    {selectedOrder.discountAmount && (
                      <View className="flex-row items-center justify-between">
                        <Text className="text-foreground">الخصم:</Text>
                        <Text className="text-success font-bold">-{selectedOrder.discountAmount} ريال</Text>
                      </View>
                    )}
                  </View>

                  {/* Status */}
                  <View className="gap-2">
                    <Text className="text-sm font-semibold text-foreground">تحديث الحالة</Text>
                    <View className="gap-2">
                      {["pending", "confirmed", "shipped", "delivered", "cancelled"].map((status) => (
                        <TouchableOpacity
                          key={status}
                          onPress={() => handleStatusChange(selectedOrder.id, status)}
                          className={`rounded-lg p-3 items-center border ${
                            selectedOrder.status === status
                              ? "bg-primary border-primary"
                              : "bg-surface border-border"
                          }`}
                        >
                          <Text
                            className={`font-semibold ${
                              selectedOrder.status === status
                                ? "text-background"
                                : "text-foreground"
                            }`}
                          >
                            {getStatusLabel(status)}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>

                  {/* Notes */}
                  {selectedOrder.notes && (
                    <View className="bg-surface border border-border rounded-lg p-4">
                      <Text className="text-xs text-muted mb-2">ملاحظات</Text>
                      <Text className="text-foreground">{selectedOrder.notes}</Text>
                    </View>
                  )}
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
