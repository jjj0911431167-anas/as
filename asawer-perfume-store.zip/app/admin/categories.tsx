import { ScrollView, Text, View, TouchableOpacity, FlatList, TextInput, Modal } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function AdminCategoriesScreen() {
  const colors = useColors();
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  });

  // Fetch data
  const { data: categories, refetch: refetchCategories } = trpc.categories.list.useQuery();
  const createCategoryMutation = trpc.categories.create.useMutation({
    onSuccess: () => {
      refetchCategories();
      setShowAddModal(false);
      setFormData({ name: "", description: "" });
    },
  });

  const handleAddCategory = async () => {
    if (!formData.name) {
      alert("يرجى إدخال اسم القسم");
      return;
    }

    try {
      await createCategoryMutation.mutateAsync(formData);
    } catch (error) {
      console.error(error);
      alert("حدث خطأ أثناء إضافة القسم");
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background" className="p-0">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="bg-primary p-6 gap-2 flex-row items-center justify-between">
          <View className="gap-2 flex-1">
            <Text className="text-2xl font-bold text-background">📂 إدارة الأقسام</Text>
          </View>
          <TouchableOpacity
            onPress={() => router.back()}
            className="bg-background/20 rounded-lg p-3"
          >
            <Text className="text-background font-semibold">رجوع</Text>
          </TouchableOpacity>
        </View>

        {/* Add Category Button */}
        <View className="px-4 mt-6 mb-6">
          <TouchableOpacity
            onPress={() => setShowAddModal(true)}
            className="bg-primary rounded-lg p-4 items-center"
          >
            <Text className="text-background font-bold text-lg">+ إضافة قسم جديد</Text>
          </TouchableOpacity>
        </View>

        {/* Categories List */}
        <View className="px-4 pb-6">
          <Text className="text-lg font-bold text-foreground mb-4">الأقسام ({categories?.length || 0})</Text>
          
          <FlatList
            data={categories}
            scrollEnabled={false}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <View className="bg-surface border border-border rounded-lg p-4 mb-3">
                <View className="flex-row items-start justify-between mb-2">
                  <View className="flex-1">
                    <Text className="text-foreground font-semibold text-lg">{item.name}</Text>
                    {item.description && (
                      <Text className="text-xs text-muted mt-1">{item.description}</Text>
                    )}
                  </View>
                  <View className="flex-row gap-2">
                    <TouchableOpacity className="bg-primary/20 rounded-lg p-2">
                      <Text className="text-primary font-semibold text-xs">تعديل</Text>
                    </TouchableOpacity>
                    <TouchableOpacity className="bg-error/20 rounded-lg p-2">
                      <Text className="text-error font-semibold text-xs">حذف</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
            ListEmptyComponent={
              <View className="items-center justify-center py-8">
                <Text className="text-muted">لا توجد أقسام حالياً</Text>
              </View>
            }
          />
        </View>
      </ScrollView>

      {/* Add Category Modal */}
      <Modal visible={showAddModal} transparent animationType="slide">
        <View className="flex-1 bg-black/50 justify-end">
          <View className="bg-background rounded-t-3xl p-6 gap-4">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-2xl font-bold text-foreground">إضافة قسم جديد</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <Text className="text-2xl text-foreground">✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Category Name */}
              <View className="gap-2 mb-4">
                <Text className="text-sm font-semibold text-foreground">اسم القسم</Text>
                <TextInput
                  placeholder="أدخل اسم القسم"
                  value={formData.name}
                  onChangeText={(text) => setFormData({ ...formData, name: text })}
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Description */}
              <View className="gap-2 mb-6">
                <Text className="text-sm font-semibold text-foreground">الوصف (اختياري)</Text>
                <TextInput
                  placeholder="أدخل وصف القسم"
                  value={formData.description}
                  onChangeText={(text) => setFormData({ ...formData, description: text })}
                  multiline
                  numberOfLines={4}
                  className="bg-surface border border-border rounded-lg p-3 text-foreground"
                  style={{ color: colors.foreground, borderColor: colors.border }}
                />
              </View>

              {/* Add Button */}
              <TouchableOpacity
                onPress={handleAddCategory}
                disabled={createCategoryMutation.isPending}
                className="bg-primary rounded-lg p-4 items-center"
              >
                <Text className="text-background font-bold text-lg">
                  {createCategoryMutation.isPending ? "جاري الإضافة..." : "إضافة القسم"}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
