import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ Categories ============
  categories: router({
    list: publicProcedure.query(() => db.getCategories()),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getCategoryById(input.id)),
    
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        image: z.string().optional(),
        order: z.number().optional(),
      }))
      .mutation(({ input }) => db.createCategory(input)),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        image: z.string().optional(),
        order: z.number().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateCategory(id, data);
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteCategory(input.id)),
  }),

  // ============ Products ============
  products: router({
    list: publicProcedure
      .input(z.object({ categoryId: z.number().optional() }).optional())
      .query(({ input }) => db.getProducts(input?.categoryId)),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getProductById(input.id)),
    
    bestsellers: publicProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(({ input }) => db.getBestsellerProducts(input?.limit)),
    
    onSale: publicProcedure.query(() => db.getOnSaleProducts()),
    
    create: publicProcedure
      .input(z.object({
        categoryId: z.number(),
        name: z.string().min(1),
        description: z.string().optional(),
        price: z.string(),
        discountPrice: z.string().optional(),
        image: z.string().optional(),
        images: z.string().optional(),
        quantity: z.number().optional(),
        isBestseller: z.boolean().optional(),
        isOnSale: z.boolean().optional(),
      }))
      .mutation(({ input }) => db.createProduct(input)),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        categoryId: z.number().optional(),
        name: z.string().optional(),
        description: z.string().optional(),
        price: z.string().optional(),
        discountPrice: z.string().optional(),
        image: z.string().optional(),
        images: z.string().optional(),
        quantity: z.number().optional(),
        isBestseller: z.boolean().optional(),
        isOnSale: z.boolean().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateProduct(id, data);
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteProduct(input.id)),
  }),

  // ============ Coupons ============
  coupons: router({
    list: publicProcedure.query(() => db.getCoupons()),
    
    validate: publicProcedure
      .input(z.object({
        code: z.string(),
        totalPrice: z.number(),
      }))
      .query(({ input }) => db.validateCoupon(input.code, input.totalPrice)),
    
    create: publicProcedure
      .input(z.object({
        code: z.string().min(1),
        description: z.string().optional(),
        discountType: z.enum(["percentage", "fixed"]),
        discountValue: z.string(),
        maxUses: z.number().optional(),
        minPurchase: z.string().optional(),
        expiryDate: z.date().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(({ input }) => db.createCoupon(input)),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        code: z.string().optional(),
        description: z.string().optional(),
        discountType: z.enum(["percentage", "fixed"]).optional(),
        discountValue: z.string().optional(),
        maxUses: z.number().optional(),
        minPurchase: z.string().optional(),
        expiryDate: z.date().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateCoupon(id, data);
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteCoupon(input.id)),
  }),

  // ============ Orders ============
  orders: router({
    list: publicProcedure.query(() => db.getOrders()),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => db.getOrderById(input.id)),
    
    getByNumber: publicProcedure
      .input(z.object({ orderNumber: z.string() }))
      .query(({ input }) => db.getOrderByNumber(input.orderNumber)),
    
    create: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        customerName: z.string(),
        customerPhone: z.string(),
        customerAddress: z.string(),
        notes: z.string().optional(),
        totalPrice: z.string(),
        discountAmount: z.string().optional(),
        couponCode: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          productName: z.string(),
          price: z.string(),
          quantity: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        const { items, ...orderData } = input;
        const orderItems = items.map(item => ({
          orderId: 0, // Will be set by createOrderWithItems
          productId: item.productId,
          productName: item.productName,
          price: item.price,
          quantity: item.quantity,
        }));
        return db.createOrderWithItems(orderData, orderItems as any);
      }),
    
    update: publicProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "confirmed", "shipped", "delivered", "cancelled"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateOrder(id, data);
      }),
    
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteOrder(input.id)),
  }),

  // ============ Order Items ============
  orderItems: router({
    getByOrderId: publicProcedure
      .input(z.object({ orderId: z.number() }))
      .query(({ input }) => db.getOrderItems(input.orderId)),
  }),

  // ============ Statistics ============
  stats: router({
    orders: publicProcedure.query(() => db.getOrderStats()),
    products: publicProcedure.query(() => db.getProductStats()),
  }),
});

export type AppRouter = typeof appRouter;
