import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  categories,
  products,
  coupons,
  orders,
  orderItems,
  users,
  InsertCategory,
  InsertProduct,
  InsertCoupon,
  InsertOrder,
  InsertOrderItem,
  InsertUser,
  Category,
  Product,
  Coupon,
  Order,
  OrderItem,
  User,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ User Management ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.updatedAt !== undefined) {
      values.updatedAt = user.updatedAt;
      updateSet.updatedAt = user.updatedAt;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.updatedAt) {
      values.updatedAt = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.updatedAt = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ Categories ============

export async function getCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories).orderBy(categories.order);
}

export async function getCategoryById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(categories).where(eq(categories.id, id));
  return result[0] || null;
}

export async function createCategory(data: InsertCategory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(categories).values(data);
  return (result as any).insertId || 0;
}

export async function updateCategory(id: number, data: Partial<InsertCategory>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(categories).set(data).where(eq(categories.id, id));
}

export async function deleteCategory(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(categories).where(eq(categories.id, id));
}

// ============ Products ============

export async function getProducts(categoryId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (categoryId) {
    return db.select().from(products).where(eq(products.categoryId, categoryId));
  }
  return db.select().from(products);
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.id, id));
  return result[0] || null;
}

export async function getBestsellerProducts(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).where(eq(products.isBestseller, true)).limit(limit);
}

export async function getOnSaleProducts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).where(eq(products.isOnSale, true));
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(products).values(data);
  return (result as any).insertId || 0;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(products).where(eq(products.id, id));
}

// ============ Coupons ============

export async function getCoupons() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(coupons).orderBy(desc(coupons.createdAt));
}

export async function getCouponByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(coupons).where(eq(coupons.code, code));
  return result[0] || null;
}

export async function createCoupon(data: InsertCoupon) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(coupons).values(data);
  return (result as any).insertId || 0;
}

export async function updateCoupon(id: number, data: Partial<InsertCoupon>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(coupons).set(data).where(eq(coupons.id, id));
}

export async function deleteCoupon(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(coupons).where(eq(coupons.id, id));
}

export async function validateCoupon(code: string, totalPrice: number) {
  const coupon = await getCouponByCode(code);
  
  if (!coupon) {
    return { valid: false, error: "الكوبون غير موجود" };
  }
  
  if (!coupon.isActive) {
    return { valid: false, error: "الكوبون غير فعال" };
  }
  
  if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
    return { valid: false, error: "انتهت صلاحية الكوبون" };
  }
  
  if (coupon.maxUses && coupon.currentUses !== null && coupon.currentUses >= coupon.maxUses) {
    return { valid: false, error: "تم استخدام الكوبون بالكامل" };
  }
  
  if (coupon.minPurchase && totalPrice < Number(coupon.minPurchase)) {
    return { valid: false, error: `الحد الأدنى للشراء هو ${coupon.minPurchase}` };
  }
  
  let discount = 0;
  if (coupon.discountType === "percentage") {
    discount = (totalPrice * Number(coupon.discountValue)) / 100;
  } else {
    discount = Number(coupon.discountValue);
  }
  
  return { valid: true, discount, coupon };
}

// ============ Orders ============

export async function getOrders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(orders).where(eq(orders.id, id));
  return result[0] || null;
}

export async function getOrderByNumber(orderNumber: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber));
  return result[0] || null;
}

export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(data);
  return (result as any).insertId || 0;
}

export async function updateOrder(id: number, data: Partial<InsertOrder>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(orders).set(data).where(eq(orders.id, id));
}

export async function deleteOrder(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(orders).where(eq(orders.id, id));
}

// ============ Order Items ============

export async function getOrderItems(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

export async function createOrderItem(data: InsertOrderItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orderItems).values(data);
  return (result as any).insertId || 0;
}

export async function createOrderWithItems(orderData: InsertOrder, items: InsertOrderItem[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const orderId = await createOrder(orderData);
  
  for (const item of items) {
    await createOrderItem({
      ...item,
      orderId,
    });
  }
  
  return orderId;
}

// ============ Statistics ============

export async function getOrderStats() {
  const db = await getDb();
  if (!db) return { totalOrders: 0, totalRevenue: 0, pendingOrders: 0 };
  
  const allOrders = await db.select().from(orders);
  const totalOrders = allOrders.length;
  const totalRevenue = allOrders.reduce((sum: number, order: Order) => sum + Number(order.totalPrice), 0);
  const pendingOrders = allOrders.filter((order: Order) => order.status === "pending").length;
  
  return { totalOrders, totalRevenue, pendingOrders };
}

export async function getProductStats() {
  const db = await getDb();
  if (!db) return { totalProducts: 0, totalCategories: 0 };
  
  const allProducts = await db.select().from(products);
  const allCategories = await db.select().from(categories);
  
  return { totalProducts: allProducts.length, totalCategories: allCategories.length };
}
